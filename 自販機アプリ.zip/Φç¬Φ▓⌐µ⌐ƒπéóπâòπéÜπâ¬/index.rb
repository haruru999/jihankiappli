require "./drink"

    drink1 = Drink.new(name:"BOSS", price:120, type:"コーヒー", taste:"微糖")
    drink2 = Drink.new(name:"三ツ矢サイダー", price:130, type:"炭酸", taste:"しゅわしゅわ")
    drink3 = Drink.new(name:"伊右衛門", price:100, type:"お茶", taste:"緑茶")
    drink4 = Drink.new(name:"バヤリースオレンジ", price:120, type:"ジュース", taste:"オレンジ")
    drink5 = Drink.new(name:"夏みかんゼリー", price:150, type:"飲むゼリー", taste:"みかんゼリー")

    drinks = [drink1, drink2, drink3, drink4, drink5]


    puts "自販機がある。どの飲み物を買いますか？"
    puts "あなたの持ち金は200円です"
    puts "-------------自販機メニュー---------------"

    index = 0
    drinks.each do |drink|
        puts "#{index}.#{drink.drink_info}"
        index += 1
    end


    puts "買いたいドリンクの番号を選んでください"
    select_drink_number = gets.chomp.to_i
    selected_drink = drinks[select_drink_number]

    puts "#{selected_drink.type}の#{selected_drink.name}を買いました。"
    puts "#{selected_drink.drink_present}"

    # #あたりが出た時
    # puts "「ラッキー！もう１本プレゼント！」"
    # #ドリンクプレゼントメソッド
    # puts "「#{self.name}」と#{present self.name}"

    # #ハズレが出た時
    # puts "「残り#{hove_money}円…もうだめぽお」"
    # puts "「ジュース飲んでんじゃねーよハゲ！」"