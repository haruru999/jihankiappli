class Drink
    attr_accessor :name, :price, :type, :taste

    def initialize(name:, price:, type:, taste:)
        self.name = name
        self.price = price
        self.type = type
        self.taste = taste
    end

    def have_money
        total_price = 200 - self.price
        return total_price
    end

    def drink_info
        return "#{self.type}の#{self.name}は#{self.price}円です"
    end

    def drink_present
        present_box = [1, 2, 3, 4, 5]
        present_number = present_box.sample
        
        if present_number == 1
            puts "ラッキー！もう１本プレゼント！"
            return "#{self.type}の#{self.name}が当たった！"
        else
            puts "「残り#{200 - self.price}円…もうだめぽお」"
            puts "「ジュース飲んでんじゃねーよハゲ！」"
        end
    end



end
